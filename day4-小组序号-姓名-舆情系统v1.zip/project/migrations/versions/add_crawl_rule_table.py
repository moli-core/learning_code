"""add crawl rule table

Revision ID: crawl_rule_001
Revises: 6fcddf2778ae
Create Date: 2025-12-04 20:25:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'crawl_rule_001'
down_revision = '6fcddf2778ae'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('crawl_rule',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('site_name', sa.String(length=128), nullable=False),
    sa.Column('site_url', sa.String(length=512), nullable=False),
    sa.Column('title_xpath', sa.String(length=512), nullable=False),
    sa.Column('content_xpath', sa.String(length=512), nullable=False),
    sa.Column('request_headers', sa.Text(), nullable=False),
    sa.Column('create_time', sa.DateTime(), nullable=False),
    sa.Column('update_time', sa.DateTime(), nullable=False),
    sa.PrimaryKeyConstraint('id')
    )


def downgrade():
    op.drop_table('crawl_rule')
