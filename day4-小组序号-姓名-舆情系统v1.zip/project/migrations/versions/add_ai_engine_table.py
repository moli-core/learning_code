"""add ai_engine table

Revision ID: add_ai_engine_table
Revises: 
Create Date: 2025-12-04 20:38:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'add_ai_engine_table'
down_revision = 'crawl_rule_001'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('ai_engine',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('provider_name', sa.String(length=128), nullable=False),
    sa.Column('api_url', sa.String(length=512), nullable=False),
    sa.Column('api_key', sa.String(length=512), nullable=False),
    sa.Column('model_name', sa.String(length=128), nullable=False),
    sa.Column('is_active', sa.Boolean(), nullable=False),
    sa.Column('create_time', sa.DateTime(), nullable=False),
    sa.Column('update_time', sa.DateTime(), nullable=False),
    sa.PrimaryKeyConstraint('id')
    )


def downgrade():
    op.drop_table('ai_engine')
