# 部署与分发指南

本指南说明如何将本项目打包并在其他设备上运行（Windows/Linux/macOS），以及离线安装、局域网访问与生产部署建议。

项目名称：政企智能舆情分析报告生成智能体应用系统  
技术栈：Flask + SQLite + Layui（前端静态本地）  
默认账号：`admin / admin123`

---

## 0. 快速开始（如何运行）

本项目提供两种运行方式，二选一：

- 方式 A：直接运行源码（推荐调试）
- 方式 B：运行打包好的 Windows EXE（如仓库存在 `dist\yq_app.exe`）

### A. 源码运行

1) 准备环境  

- 安装 Python 3.10+  
- 确保能访问外网（舆情采集依赖访问百度新闻）；若无外网，可先按“4. 离线安装”准备离线包

2) 安装依赖并启动（Windows PowerShell 示例）

```powershell
# 进入项目根目录（包含 project/ 子目录）
python -m venv venv
.\venv\Scripts\activate
python -m pip install -U pip
pip install -r project/requirements.txt

# 启动开发服务
python project/run.py
```

3) 访问  
浏览器打开 <http://127.0.0.1:5000>  
默认账号：admin / admin123

4) 常见报错快速修复  
如果启动时报：

```
AttributeError: module 'sqlalchemy' has no attribute '__all__'
```

说明环境中装入了 SQLAlchemy 2.x，请强制安装本项目兼容版本：

```powershell
pip install "SQLAlchemy==1.4.49" "Flask-SQLAlchemy==2.5.1"
```

然后再次执行 `python project/run.py`。

5) 局域网访问（可选）  
需要同网段其他设备访问时：

```powershell
$env:FLASK_APP="project/run.py"
$env:FLASK_ENV="production"
flask run --host=0.0.0.0 --port=5000
```

或设置环境变量后运行：`YQ_HOST=0.0.0.0`、`YQ_PORT=5000`。

### B. Windows EXE 运行

如仓库内存在 `dist\yq_app.exe`：

```powershell
# 双击 dist\yq_app.exe 即可
# 或带环境变量运行（示例）
$env:YQ_HOST="127.0.0.1"
$env:YQ_PORT="5000"
$env:YQ_DEBUG="0"
.\dist\yq_app.exe
```

- 首次运行会在 EXE 同目录生成 SQLite 数据库 `app.db`  
- 防火墙弹窗请选择“允许访问”  
- 若端口占用，设置 `YQ_PORT=5001` 再运行

> 如未找到 `dist\yq_app.exe`，请按上面的“源码运行”，或参考第 13 节自行构建 EXE。

---

## 1. 打包与传输

推荐直接打包整个 `project/` 目录及根部文档到压缩包（不要包含本机的虚拟环境 venv，以减少体积）。

- 建议包含的内容（根目录）：
  - `project/`（代码、模板、静态、配置、数据库文件等）
  - `project/requirements.txt`
  - `project/run.py`
  - `DEPLOY.md`（本文件）
  - 可选：`project/app.db`（如需携带现有数据；如不携带，将自动初始化空库并生成默认管理员）

- 不要打包：
  - 本机虚拟环境文件夹（如 `venv/`）
  - IDE 产生的 `.vscode/`、`.idea/` 等

将上述内容压缩为 `app_bundle.zip` 复制到目标机器后解压即可。

---

## 2. 运行环境准备

- Python：建议 Python 3.10+（已在 Windows 11 / Python 3.14 上验证）
- 网络：如需使用“舆情采集”模块，请保证目标机器可以访问 `https://www.baidu.com`（或配置代理）
- 操作系统依赖：本项目依赖较少，仅需 Python。无需 Node、数据库服务（SQLite 文件内置）

---

## 3. 在线安装并运行（标准方式）

以 Windows 为例（Linux/macOS 命令基本相同）：

```powershell
# 进入解压后的目录（包含 project/）
cd path\to\app_bundle

# 创建并激活虚拟环境（Windows）
python -m venv venv
.\venv\Scripts\activate

# 升级 pip（可选）
python -m pip install -U pip

# 安装依赖（已去除需要编译的 lxml，安装更轻量）
pip install -r project/requirements.txt

# 运行（开发模式）
python project/run.py
```

看到终端输出：

```
* Running on http://127.0.0.1:5000
```

浏览器访问 <http://127.0.0.1:5000>

- 默认管理员：`admin / admin123`
- 登录后右上角可进入“舆情采集”或“后台管理”

---

## 4. 离线安装（无外网环境）

在有外网的机器上预下载依赖并打包带走：

```bash
# 在有网环境中执行
cd path/to/app_bundle
python -m venv venv && source venv/bin/activate  # Windows 用 .\venv\Scripts\activate
mkdir wheelhouse
pip download -r project/requirements.txt -d wheelhouse
```

将整个 `wheelhouse/` 目录连同项目一起复制到离线机器。然后在离线机器执行：

```bash
cd path\to\app_bundle
python -m venv venv
.\venv\Scripts\activate
pip install --no-index --find-links wheelhouse -r project/requirements.txt
python project/run.py
```

---

## 5. 局域网访问（同网段其他设备访问）

开发模式默认仅本机访问。如果需要让局域网其他设备访问：

方式 A：使用 `flask run` 指定监听地址

```powershell
# Windows PowerShell
$env:FLASK_APP="project/run.py"
$env:FLASK_ENV="production"
flask run --host=0.0.0.0 --port=5000
```

方式 B：修改运行脚本（不改代码时可忽略）
> 如需长期监听 0.0.0.0，可将 `project/run.py` 中的 `app.run(debug=True)` 改为：
> `app.run(host="0.0.0.0", port=5000, debug=False)`

注意：首次放行防火墙中的 5000 端口；局域网设备使用 `http://<本机局域网IP>:5000` 访问。

---

## 6. 生产部署建议（可选）

开发服务器仅用于本地调试。上线或长期运行建议：

- Windows：使用 Waitress（纯 Python WSGI 服务器）

  ```powershell
  pip install waitress
  # app 实例在 project/run.py 中导出
  waitress-serve --listen=0.0.0.0:5000 project.run:app
  ```

- Linux：使用 Gunicorn + Nginx 反向代理（略，可按常规 Flask 部署流程）

- 后台守护：可使用 `pm2`（pm2-py）、`nssm`/Windows 服务、或 `systemd`（Linux）

- 安全项：
  - 修改 `SECRET_KEY`：编辑 `project/app/__init__.py` 中的 `SECRET_KEY`，改成随机复杂字符串
  - 首次登录后，立即修改管理员密码
  - 如提供公网访问，建议放在内网或使用 VPN/反向代理、安全组限制等

---

## 7. 配置与数据

- 配置文件：`project/config/default.py`（默认 SQLite 路径、追踪开关）
- 数据库：`project/app.db`（SQLite 文件）
  - 可直接携带该文件到其他机器（包含账号、系统设置等）
  - 如删除该文件，首次启动会自动建库并注入 `admin/admin123`

- 系统设置（应用名称/LOGO）：登录管理员 → 后台管理 → 系统设置

---

## 8. 舆情采集模块说明

- 页面：`/crawl`（登录后访问）
- 接口：`/api/crawl?q=关键词&limit=20`
- 依赖：`requests` 和 `beautifulsoup4`（已在 `requirements.txt` 中）
- 外网：需能访问 `https://www.baidu.com`。若公司环境需要代理，请在系统级配置或在运行时设置代理环境变量：

  ```bash
  set HTTP_PROXY=http://proxy_host:port
  set HTTPS_PROXY=http://proxy_host:port
  ```

---

## 9. 常见问题

- 执行 `pip install -r project/requirements.txt` 报错 "No such file or directory"
  - 当前已位于 `project/` 目录，请改为：`pip install -r requirements.txt`
  - 启动命令改为：`python run.py`（而不是 `python project/run.py`）
- 浏览器提示“无法访问此页面 / 127.0.0.1 拒绝连接”
  - 确认终端正在运行 `python project/run.py`
  - 端口被占用：改用 `--port=5001` 或修改运行脚本端口
  - 防火墙/代理拦截：尝试本机浏览器访问、暂时关闭拦截规则测试

- 登录后看不到“后台管理”
  - 使用 admin 登录；或刷新页面（已修复注入当前角色逻辑）
  - 确保 `project/app/__init__.py` 中初始化逻辑已运行（会保证内置 admin 为 admin 角色）

- 采集结果为空或很少
  - 关键字过于稀疏/限制：更换关键词
  - 访问被限制：添加合适的代理，或降低请求频率

---

## 10. 目录结构简表

```
project/
  app/
    __init__.py        # Flask 应用工厂/DB 初始化/默认管理员注入
    models.py          # User / Setting 模型
    routes.py          # 登录/退出/后台/采集页面与接口等
    crawler.py         # 舆情采集（百度新闻搜索抓取）
  templates/
    login.html
    index.html
    admin.html
    crawl.html
  static/
    layui/...          # 本地 Layui 资源
  config/
    default.py         # SQLite 等配置
  requirements.txt
  run.py               # 入口（本地开发）
```

---

## 11. 快速检查清单

- [ ] 目标机安装 Python 3.10+（若使用 EXE 可不装 Python）
- [ ] 创建 venv 并 `pip install -r project/requirements.txt`（源码运行/构建时需要）
- [ ] 运行 `python project/run.py` 或双击 `dist\yq_app.exe`
- [ ] 更改 `SECRET_KEY` 与管理员密码（生产环境）
- [ ] 需要 LAN 访问时，改为 `flask run --host=0.0.0.0` 或在 EXE 前设置 `YQ_HOST=0.0.0.0`
- [ ] 需要长期运行时，换用 Waitress/Gunicorn，配置守护/反向代理

---

## 12. Windows EXE（免安装运行）

已提供打包产物：`dist\yq_app.exe`。可在 Windows 上直接运行，无需安装 Python。

### 12.1 快速运行

- 双击 `dist\yq_app.exe`，看到控制台输出：

  ```
  * Running on http://127.0.0.1:5000
  ```

  使用浏览器访问 `http://127.0.0.1:5000`。

- 可通过环境变量调整监听地址/端口（示例）：
  - PowerShell

    ```powershell
    $env:YQ_HOST="127.0.0.1"
    $env:YQ_PORT="5000"
    $env:YQ_DEBUG="0"
    .\dist\yq_app.exe
    ```

  - CMD

    ```bat
    set YQ_HOST=127.0.0.1
    set YQ_PORT=5000
    set YQ_DEBUG=0
    dist\yq_app.exe
    ```

  - Git Bash

    ```bash
    export YQ_HOST=127.0.0.1
    export YQ_PORT=5000
    export YQ_DEBUG=0
    ./dist/yq_app.exe
    ```

### 12.2 注意事项

- 首次运行会在 EXE 同目录生成 `app.db`（SQLite），请确保目录可写。
- Windows 可能弹出 SmartScreen 或防火墙提示，请选择“仍要运行/允许访问”。
- 端口占用时更换端口（如 5001）：设置 `YQ_PORT=5001` 后再运行。
- 需要被局域网访问时：设置 `YQ_HOST=0.0.0.0` 并在防火墙放行端口。
- 退出：在控制台窗口按 `Ctrl+C` 停止服务。

### 12.3 一键启动脚本

仓库提供示例脚本：`scripts\run_exe_example.bat`，可编辑其中的 `YQ_HOST/YQ_PORT/YQ_DEBUG` 后双击执行，便于桌面快捷方式/开机自启。

---

## 13. 从源码构建/更新 EXE

依赖：Python 3.10+、已安装项目依赖与 PyInstaller。

### 13.1 一键打包（推荐）

```powershell
# 安装依赖（首次）
python -m pip install -U pip
pip install -r project/requirements.txt
pip install pyinstaller

# 执行脚本
scripts\build_exe.bat
```

输出：`dist\yq_app.exe`。该脚本已将 `project\templates/`、`project\static/`、`project\config/` 一并打包，首次运行会在 EXE 同目录创建 `app.db`。

### 13.2 自定义图标与版本信息（可选）

- 自定义图标：在脚本或命令追加 `--icon assets\app.ico`（准备 `assets\app.ico`）。
- 版本信息文件（`version.txt` 示例）与 `--version-file` 搭配，用于在属性中显示公司/版权等元数据。

---

## 14. EXE 常见问题

- 看到“Debug mode: on”
  - 说明当前开启了调试模式。确保在启动前设置 `YQ_DEBUG=0` 并重新运行。
- “Address already in use”
  - 端口被占用。设置 `YQ_PORT=5001` 或先关闭占用该端口的进程。
- 数据库创建失败/只读
  - 将 EXE 放到可写目录运行（如桌面、文档或任意普通文件夹），首次运行自动生成 `app.db`。
- 无法从其他设备访问
  - 设置 `YQ_HOST=0.0.0.0`，在系统防火墙放行相应端口，使用 `http://<本机IP>:<端口>` 访问。
- SmartScreen 拦截
  - 选择“更多信息 → 仍要运行”。如在企业环境，请联系管理员进行白名单/签名处理。

---

如需进一步帮助（如 Dockerfile、Windows 服务化脚本、CI/CD 等），可在仓库新增对应文件并完善本指南。
