import sys

# Ensure we can import the project package `app`
sys.path.append('project')

from app import create_app, db  # type: ignore
from app.models import User  # type: ignore

app = create_app()

def main():
    with app.app_context():
        users = User.query.order_by(User.id).all()
        print("Users before fix:", [(u.id, u.username, u.role) for u in users])
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            print("No 'admin' user found.")
            return
        if admin.role != 'admin':
            print(f"Fixing role for admin: {admin.role} -> admin")
            admin.role = 'admin'
            db.session.commit()
        else:
            print("Admin role already 'admin'.")
        users = User.query.order_by(User.id).all()
        print("Users after  fix:", [(u.id, u.username, u.role) for u in users])

if __name__ == "__main__":
    main()
