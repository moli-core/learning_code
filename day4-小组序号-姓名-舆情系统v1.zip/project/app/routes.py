from flask import render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import check_password_hash, generate_password_hash
from . import db

def register_routes(app):
    from .models import User, Setting, NewsData, DeepCrawlData, CrawlRule, AIEngine
    from .crawler import fetch_baidu_news, fetch_baidu_news_enhanced
    from functools import wraps
    import hashlib
    from datetime import datetime
    import json

    # 将当前用户和是否管理员注入到所有模板，避免依赖可能滞后的 session.role
    @app.context_processor
    def inject_user():
        try:
            uid = session.get('user_id')
            user = User.query.get(uid) if uid else None
            return dict(current_user=user, is_admin=bool(user and user.role == 'admin'))
        except Exception:
            return dict(current_user=None, is_admin=False)

    # 登录态守卫
    def login_required(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not session.get('user_id'):
                return redirect(url_for('login'))
            return f(*args, **kwargs)
        return decorated

    # 角色守卫
    def role_required(role):
        def deco(f):
            @wraps(f)
            def decorated(*args, **kwargs):
                if session.get('role') != role:
                    flash('权限不足', 'error')
                    return redirect(url_for('index'))
                return f(*args, **kwargs)
            return decorated
        return deco
    @app.route('/')
    def index():
        # Default page: if unauthenticated, redirect to login
        if not session.get('user_id'):
            return redirect(url_for('login'))
        settings = {s.key: s.value for s in Setting.query.all()}
        return render_template('index.html', settings=settings)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        # Load settings to render app name/logo on login page as well
        settings = {s.key: s.value for s in Setting.query.all()}
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            remember = request.form.get('remember') == 'on'
            user = User.query.filter_by(username=username).first()
            if user and check_password_hash(user.password, password):
                # Harden: ensure built-in admin always has admin role
                if user.username == 'admin' and user.role != 'admin':
                    user.role = 'admin'
                    db.session.commit()
                session['user_id'] = user.id
                session['username'] = user.username
                session['role'] = user.role
                session.permanent = remember
                flash('登录成功', 'success')
                return redirect(url_for('index'))
            else:
                flash('用户名或密码错误', 'error')
                return render_template('login.html', username=username, settings=settings)
        return render_template('login.html', settings=settings)

    @app.route('/logout')
    @login_required
    def logout():
        session.clear()
        flash('已退出登录', 'success')
        return redirect(url_for('login'))

    @app.route('/dashboard')
    @login_required
    def dashboard():
        settings = {s.key: s.value for s in Setting.query.all()}
        return render_template('index.html', settings=settings)

    # 舆情采集页面
    @app.route('/crawl')
    @login_required
    def crawl_page():
        settings = {s.key: s.value for s in Setting.query.all()}
        return render_template('crawl.html', settings=settings)

    # 舆情采集接口：?q=关键词&limit=20
    @app.route('/api/crawl')
    @login_required
    def api_crawl():
        q = (request.args.get('q') or '').strip()
        try:
            limit = int(request.args.get('limit') or 20)
        except Exception:
            limit = 20
        if not q:
            return jsonify({"code": 400, "msg": "missing param q", "data": []}), 400
        try:
            items = fetch_baidu_news(q, limit=limit)
            data = [{
                "标题": it.get("标题") or "",
                "概要": it.get("概要") or "",
                "封面": it.get("封面"),
                "原始URL": it.get("原始URL"),
                "来源": it.get("来源") or ""
            } for it in items]
            
            # 保存数据到数据库
            for item in items:
                unique_content = f"{item.get('标题')}|{item.get('原始URL')}|{item.get('来源')}"
                unique_hash = hashlib.md5(unique_content.encode('utf-8')).hexdigest()
                existing = NewsData.query.filter_by(unique_hash=unique_hash).first()
                if not existing:
                    news_data = NewsData(
                        keyword=q,
                        title=item.get('标题'),
                        summary=item.get('概要'),
                        cover=item.get('封面'),
                        url=item.get('原始URL'),
                        source=item.get('来源'),
                        unique_hash=unique_hash
                    )
                    db.session.add(news_data)
            db.session.commit()
            
            return jsonify({"code": 0, "msg": "ok", "count": len(data), "data": data})
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e), "data": []}), 500

    @app.route('/admin')
    @login_required
    @role_required('admin')
    def admin():
        users = User.query.all()
        settings = {s.key: s.value for s in Setting.query.all()}
        return render_template('admin.html', users=users, settings=settings)

    @app.route('/admin/users/add', methods=['POST'])
    @login_required
    @role_required('admin')
    def admin_users_add():
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        role = request.form.get('role', 'user')
        if not username or not password:
            flash('用户名和密码不能为空', 'error')
            return redirect(url_for('admin'))
        if User.query.filter_by(username=username).first():
            flash('用户名已存在', 'error')
            return redirect(url_for('admin'))
        u = User(username=username, password=generate_password_hash(password), role=role)
        db.session.add(u)
        db.session.commit()
        flash('用户已创建', 'success')
        return redirect(url_for('admin'))

    @app.route('/admin/users/delete/<int:uid>', methods=['POST'])
    @login_required
    @role_required('admin')
    def admin_users_delete(uid):
        u = User.query.get_or_404(uid)
        if u.username == 'admin':
            flash('内置管理员不可删除', 'error')
            return redirect(url_for('admin'))
        db.session.delete(u)
        db.session.commit()
        flash('已删除', 'success')
        return redirect(url_for('admin'))

    @app.route('/admin/users/reset/<int:uid>', methods=['POST'])
    @login_required
    @role_required('admin')
    def admin_users_reset(uid):
        u = User.query.get_or_404(uid)
        u.password = generate_password_hash('123456')
        db.session.commit()
        flash('密码已重置为 123456', 'success')
        return redirect(url_for('admin'))

    @app.route('/admin/settings', methods=['POST'])
    @login_required
    @role_required('admin')
    def admin_settings():
        app_name = request.form.get('app_name', '').strip()
        logo_url = request.form.get('logo_url', '').strip()
        for k, v in [('app_name', app_name), ('logo_url', logo_url)]:
            s = Setting.query.get(k)
            if s:
                s.value = v
            else:
                db.session.add(Setting(key=k, value=v))
        db.session.commit()
        flash('设置已保存', 'success')
        return redirect(url_for('admin'))

    # 增强版舆情采集接口：支持多页爬取和数据存储
    @app.route('/api/crawl_enhanced', methods=['POST'])
    @login_required
    def api_crawl_enhanced():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据", "data": []}), 400
        
        keyword = data.get('keyword', '').strip()
        total_limit = data.get('total_limit', 50)
        pages = data.get('pages', 3)
        save_to_db = data.get('save_to_db', False)
        
        if not keyword:
            return jsonify({"code": 400, "msg": "缺少关键词参数", "data": []}), 400
        
        try:
            # 使用增强版爬虫
            items = fetch_baidu_news_enhanced(
                keyword=keyword, 
                total_limit=total_limit, 
                pages=pages,
                enable_delay=True
            )
            
            saved_count = 0
            if save_to_db:
                # 保存到数据库
                for item in items:
                    # 生成唯一标识
                    unique_content = f"{item.get('title', '')}|{item.get('url', '')}|{item.get('source', '')}"
                    unique_hash = hashlib.md5(unique_content.encode('utf-8')).hexdigest()
                    
                    # 检查是否已存在
                    existing = NewsData.query.filter_by(unique_hash=unique_hash).first()
                    if not existing:
                        news_data = NewsData(
                            keyword=keyword,
                            title=item.get('title', ''),
                            summary=item.get('summary', ''),
                            cover=item.get('cover', ''),
                            url=item.get('url', ''),
                            source=item.get('source', ''),
                            unique_hash=unique_hash,
                            crawl_time=datetime.now()
                        )
                        db.session.add(news_data)
                        saved_count += 1
                
                db.session.commit()
            
            result_data = [{
                "标题": it.get("title") or "",
                "概要": it.get("summary") or "",
                "封面": it.get("cover"),
                "原始URL": it.get("url"),
                "来源": it.get("source") or "",
                "页码": it.get("page", 1)
            } for it in items]
            
            return jsonify({
                "code": 0, 
                "msg": "ok", 
                "count": len(result_data),
                "saved_count": saved_count,
                "data": result_data
            })
            
        except Exception as e:
            return jsonify({"code": 500, "msg": str(e), "data": []}), 500

    # 数据管理页面
    @app.route('/data')
    @login_required
    def data_management():
        settings = {s.key: s.value for s in Setting.query.all()}
        # 获取关键词列表用于筛选
        keywords = db.session.query(NewsData.keyword).distinct().all()
        keyword_list = [k[0] for k in keywords] if keywords else []
        return render_template('data.html', settings=settings, keywords=keyword_list)

    # 获取存储的数据接口
    @app.route('/api/data')
    @login_required
    def api_get_data():
        # 获取单条数据详情
        data_id = request.args.get('id')
        if data_id:
            item = DeepCrawlData.query.get(data_id)
            if not item:
                return jsonify({"code": 404, "msg": "数据不存在"}), 404
            return jsonify({
                "code": 0,
                "data": {
                    "id": item.id,
                    "keyword": item.keyword,
                    "title": item.title,
                    "summary": item.summary,
                    "full_content": item.full_content,
                    "cover": item.cover,
                    "url": item.url,
                    "source": item.source,
                    "author": item.author,
                    "publish_time": item.publish_time.strftime('%Y-%m-%d %H:%M:%S') if item.publish_time else None,
                    "crawl_time": item.crawl_time.strftime('%Y-%m-%d %H:%M:%S')
                }
            })
        
        keyword = request.args.get('keyword', '').strip()
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))
        
        query = DeepCrawlData.query
        if keyword:
            query = query.filter(DeepCrawlData.keyword == keyword)
        
        # 按爬取时间倒序排列
        data_list = query.order_by(DeepCrawlData.crawl_time.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        result = {
            "code": 0,
            "msg": "ok",
            "data": [{
                "id": item.id,
                "关键词": item.keyword,
                "标题": item.title,
                "概要": item.summary,
                "封面": item.cover,
                "原始URL": item.url,
                "来源": item.source,
                "爬取时间": item.crawl_time.strftime('%Y-%m-%d %H:%M:%S')
            } for item in data_list.items],
            "total": data_list.total,
            "page": page,
            "per_page": per_page,
            "pages": data_list.pages
        }
        
        return jsonify(result)

    # 删除数据接口
    @app.route('/api/data/delete', methods=['POST'])
    @login_required
    def api_delete_data():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        ids = data.get('ids', [])
        if not ids:
            return jsonify({"code": 400, "msg": "缺少要删除的ID列表"}), 400
        
        try:
            deleted_count = 0
            for data_id in ids:
                news_data = NewsData.query.get(data_id)
                if news_data:
                    db.session.delete(news_data)
                    deleted_count += 1
            
            db.session.commit()
            return jsonify({"code": 0, "msg": f"成功删除 {deleted_count} 条数据"})
            
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 批量删除关键词数据接口
    @app.route('/api/data/delete_by_keyword', methods=['POST'])
    @login_required
    def api_delete_by_keyword():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        keyword = data.get('keyword', '').strip()
        if not keyword:
            return jsonify({"code": 400, "msg": "缺少关键词参数"}), 400
        
        try:
            deleted_count = NewsData.query.filter_by(keyword=keyword).delete()
            db.session.commit()
            return jsonify({"code": 0, "msg": f"成功删除关键词 '{keyword}' 的 {deleted_count} 条数据"})
            
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 单条数据保存接口
    @app.route('/api/data/save_single', methods=['POST'])
    @login_required
    def api_save_single_data():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        data_id = data.get('id')
        if not data_id:
            return jsonify({"code": 400, "msg": "缺少数据ID"}), 400
        
        try:
            news_data = NewsData.query.get(data_id)
            if not news_data:
                return jsonify({"code": 404, "msg": "数据不存在"}), 404
            
            # 更新保存时间
            news_data.crawl_time = datetime.now()
            db.session.commit()
            
            return jsonify({"code": 0, "msg": "数据保存成功"})
            
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 数据采集管理页面（管理员）
    @app.route('/crawl_manage')
    @login_required
    @role_required('admin')
    def crawl_manage():
        settings = {s.key: s.value for s in Setting.query.all()}
        keywords = db.session.query(DeepCrawlData.keyword).distinct().all()
        keyword_list = [k[0] for k in keywords] if keywords else []
        return render_template('crawl_manage.html', settings=settings, keywords=keyword_list)

    # 深度采集API（不自动保存）
    @app.route('/api/deep_crawl', methods=['POST'])
    @login_required
    @role_required('admin')
    def api_deep_crawl():
        try:
            data = request.get_json()
            if not data:
                return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
            
            keyword = data.get('keyword', '').strip()
            total_limit = int(data.get('total_limit', 50))
            pages = int(data.get('pages', 3))
            
            if not keyword:
                return jsonify({"code": 400, "msg": "缺少关键词参数"}), 400
            
            items = fetch_baidu_news_enhanced(keyword=keyword, total_limit=total_limit, pages=pages, enable_delay=True)
            
            if not items:
                return jsonify({"code": 0, "msg": "未采集到数据", "count": 0, "saved_count": 0})
            
            # 保存到深度采集表
            saved_count = 0
            for item in items:
                unique_content = f"{item.get('title', '')}|{item.get('url', '')}|{item.get('source', '')}"
                unique_hash = hashlib.md5(unique_content.encode('utf-8')).hexdigest()
                
                existing = DeepCrawlData.query.filter_by(unique_hash=unique_hash).first()
                if not existing:
                    deep_data = DeepCrawlData(
                        keyword=keyword,
                        title=item.get('title', ''),
                        summary=item.get('summary', ''),
                        cover=item.get('cover', ''),
                        url=item.get('url', ''),
                        source=item.get('source', ''),
                        unique_hash=unique_hash,
                        is_stored=False
                    )
                    db.session.add(deep_data)
                    saved_count += 1
            
            db.session.commit()
            
            return jsonify({
                "code": 0,
                "msg": "深度采集完成",
                "count": len(items),
                "saved_count": saved_count
            })
            
        except Exception as e:
            db.session.rollback()
            import traceback
            error_detail = traceback.format_exc()
            print(f"深度采集错误: {error_detail}")
            return jsonify({"code": 500, "msg": f"采集失败: {str(e)}"}), 500

    # 获取深度采集数据
    @app.route('/api/deep_crawl_data')
    @login_required
    @role_required('admin')
    def api_get_deep_crawl_data():
        keyword = request.args.get('keyword', '').strip()
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))

        # 获取关键词列表用于筛选
        all_keywords_query = db.session.query(DeepCrawlData.keyword).distinct().all()
        keyword_list = [k[0] for k in all_keywords_query if k[0]]
        
        query = DeepCrawlData.query
        if keyword:
            query = query.filter(DeepCrawlData.keyword == keyword)
        
        data_list = query.order_by(DeepCrawlData.crawl_time.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        result = {
            "code": 0,
            "msg": "ok",
            "data": [{
                "id": item.id,
                "keyword": item.keyword,
                "title": item.title,
                "summary": item.summary,
                "cover": item.cover,
                "url": item.url,
                "source": item.source,
                "crawl_time": item.crawl_time.strftime('%Y-%m-%d %H:%M:%S'),
                "is_stored": item.is_stored
            } for item in data_list.items],
            "total": data_list.total,
            "page": page,
            "per_page": per_page,
            "pages": data_list.pages,
            "keywords": keyword_list
        }
        
        return jsonify(result)

    # 批量存储深度采集数据到主表
    @app.route('/api/deep_crawl_data/store', methods=['POST'])
    @login_required
    @role_required('admin')
    def api_store_deep_crawl_data():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        ids = data.get('ids', [])
        if not ids:
            return jsonify({"code": 400, "msg": "缺少要存储的ID列表"}), 400
        
        try:
            stored_count = 0
            for data_id in ids:
                deep_data = DeepCrawlData.query.get(data_id)
                if deep_data and not deep_data.is_stored:
                    # 检查主表是否已存在
                    existing = NewsData.query.filter_by(unique_hash=deep_data.unique_hash).first()
                    if not existing:
                        news_data = NewsData(
                            keyword=deep_data.keyword,
                            title=deep_data.title,
                            summary=deep_data.summary,
                            cover=deep_data.cover,
                            url=deep_data.url,
                            source=deep_data.source,
                            unique_hash=deep_data.unique_hash,
                            crawl_time=datetime.now()
                        )
                        db.session.add(news_data)
                        deep_data.is_stored = True
                        stored_count += 1
            
            db.session.commit()
            return jsonify({"code": 0, "msg": f"成功存储 {stored_count} 条数据到主表"})
            
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 删除深度采集数据
    @app.route('/api/deep_crawl_data/delete', methods=['POST'])
    @login_required
    @role_required('admin')
    def api_delete_deep_crawl_data():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        ids = data.get('ids', [])
        if not ids:
            return jsonify({"code": 400, "msg": "缺少要删除的ID列表"}), 400
        
        try:
            deleted_count = 0
            for data_id in ids:
                deep_data = DeepCrawlData.query.get(data_id)
                if deep_data:
                    db.session.delete(deep_data)
                    deleted_count += 1
            
            db.session.commit()
            return jsonify({"code": 0, "msg": f"成功删除 {deleted_count} 条数据"})
            
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 数据仓库管理页面
    @app.route('/warehouse')
    @login_required
    def warehouse():
        settings = {s.key: s.value for s in Setting.query.all()}
        return render_template('warehouse.html', settings=settings)

    # 获取数据仓库关键词列表
    @app.route('/api/warehouse/keywords')
    @login_required
    def api_warehouse_keywords():
        keywords = db.session.query(NewsData.keyword).distinct().all()
        keyword_list = [k[0] for k in keywords if k[0]]
        return jsonify({"code": 0, "data": keyword_list})

    # 获取数据仓库数据
    @app.route('/api/warehouse/data')
    @login_required
    def api_warehouse_data():
        keyword = request.args.get('keyword', '').strip()
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        
        query = NewsData.query
        if keyword:
            query = query.filter(NewsData.keyword == keyword)
        
        paginated = query.order_by(NewsData.crawl_time.desc()).paginate(
            page=page, per_page=limit, error_out=False
        )
        
        return jsonify({
            "code": 0,
            "msg": "ok",
            "count": paginated.total,
            "data": [{
                "id": item.id,
                "keyword": item.keyword,
                "title": item.title,
                "summary": item.summary,
                "source": item.source,
                "url": item.url,
                "crawl_time": item.crawl_time.strftime('%Y-%m-%d %H:%M:%S'),
                "deep_crawl_status": DeepCrawlData.query.filter_by(unique_hash=item.unique_hash).first() is not None
            } for item in paginated.items]
        })

    # 获取数据仓库详细内容
    @app.route('/api/warehouse/detail')
    @login_required
    def api_warehouse_detail():
        data_id = request.args.get('id')
        if not data_id:
            return jsonify({"code": 400, "msg": "缺少数据ID"}), 400
        
        news_data = NewsData.query.get(data_id)
        if not news_data:
            return jsonify({"code": 404, "msg": "数据不存在"}), 404
        
        deep_data = DeepCrawlData.query.filter_by(unique_hash=news_data.unique_hash).first()
        
        return jsonify({
            "code": 0,
            "data": {
                "id": news_data.id,
                "title": news_data.title,
                "source": news_data.source,
                "crawl_time": news_data.crawl_time.strftime('%Y-%m-%d %H:%M:%S'),
                "full_content": deep_data.full_content if deep_data else None
            }
        })

    # 数据仓库深度采集
    @app.route('/api/warehouse/deep_crawl', methods=['POST'])
    @login_required
    def api_warehouse_deep_crawl():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        data_id = data.get('id')
        if not data_id:
            return jsonify({"code": 400, "msg": "缺少数据ID"}), 400
        
        try:
            news_data = NewsData.query.get(data_id)
            if not news_data:
                return jsonify({"code": 404, "msg": "数据不存在"}), 404
            
            existing = DeepCrawlData.query.filter_by(unique_hash=news_data.unique_hash).first()
            if existing:
                return jsonify({"code": 0, "msg": "该数据已完成深度采集"})
            
            # 优先使用绑定的规则
            result = None
            if news_data.crawl_rules:
                from .crawler import fetch_with_rule
                for rule in news_data.crawl_rules:
                    try:
                        headers = json.loads(rule.request_headers)
                        result = fetch_with_rule(news_data.url, rule.title_xpath, rule.content_xpath, headers)
                        if result['success']:
                            break
                    except:
                        continue
            
            # 如果绑定规则失败，使用智能分析
            if not result or not result['success']:
                from .crawler import fetch_article_content_detailed
                result = fetch_article_content_detailed(news_data.url, news_data.source)
                
                # 保存新规则到规则库
                if result.get('rule'):
                    rule_data = result['rule']
                    existing_rule = CrawlRule.query.filter_by(site_url=rule_data['site_url']).first()
                    if not existing_rule:
                        new_rule = CrawlRule(
                            site_name=rule_data['site_name'],
                            site_url=rule_data['site_url'],
                            title_xpath=rule_data['title_xpath'],
                            content_xpath=rule_data['content_xpath'],
                            request_headers=json.dumps(rule_data['headers'], ensure_ascii=False)
                        )
                        db.session.add(new_rule)
            
            if not result['success']:
                return jsonify({
                    "code": 500,
                    "msg": "采集失败",
                    "process": result['process']
                }), 500
            
            deep_data = DeepCrawlData(
                keyword=news_data.keyword,
                title=result['title'],
                summary=news_data.summary,
                full_content=result['content'],
                cover=news_data.cover,
                url=news_data.url,
                source=news_data.source,
                unique_hash=news_data.unique_hash
            )
            db.session.add(deep_data)
            db.session.commit()
            
            return jsonify({
                "code": 0,
                "msg": "深度采集成功",
                "process": result['process'],
                "title": result['title'],
                "content_length": len(result['content'])
            })
        except Exception as e:
            db.session.rollback()
            import traceback
            return jsonify({
                "code": 500,
                "msg": f"深度采集失败: {str(e)}",
                "process": [{"step": "错误", "status": "失败", "detail": traceback.format_exc()}]
            }), 500

    # 更新数据仓库数据
    @app.route('/api/warehouse/update', methods=['POST'])
    @login_required
    def api_warehouse_update():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        data_id = data.get('id')
        if not data_id:
            return jsonify({"code": 400, "msg": "缺少数据ID"}), 400
        
        try:
            news_data = NewsData.query.get(data_id)
            if not news_data:
                return jsonify({"code": 404, "msg": "数据不存在"}), 404
            
            news_data.keyword = data.get('keyword', news_data.keyword)
            news_data.title = data.get('title', news_data.title)
            news_data.summary = data.get('summary', news_data.summary)
            news_data.source = data.get('source', news_data.source)
            news_data.url = data.get('url', news_data.url)
            
            db.session.commit()
            return jsonify({"code": 0, "msg": "更新成功"})
            
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 删除数据仓库数据
    @app.route('/api/warehouse/delete', methods=['POST'])
    @login_required
    def api_warehouse_delete():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        ids = data.get('ids', [])
        if not ids:
            return jsonify({"code": 400, "msg": "缺少要删除的ID列表"}), 400
        
        try:
            deleted_count = NewsData.query.filter(NewsData.id.in_(ids)).delete(synchronize_session=False)
            db.session.commit()
            return jsonify({"code": 0, "msg": f"成功删除 {deleted_count} 条数据"})
            
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 采集规则库页面
    @app.route('/crawl_rules')
    @login_required
    @role_required('admin')
    def crawl_rules():
        settings = {s.key: s.value for s in Setting.query.all()}
        return render_template('crawl_rules.html', settings=settings)

    # 获取采集规则列表
    @app.route('/api/crawl_rules')
    @login_required
    @role_required('admin')
    def api_get_crawl_rules():
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        
        paginated = CrawlRule.query.order_by(CrawlRule.create_time.desc()).paginate(
            page=page, per_page=limit, error_out=False
        )
        
        return jsonify({
            "code": 0,
            "msg": "ok",
            "count": paginated.total,
            "data": [{
                "id": item.id,
                "site_name": item.site_name,
                "site_url": item.site_url,
                "title_xpath": item.title_xpath,
                "content_xpath": item.content_xpath,
                "request_headers": item.request_headers,
                "create_time": item.create_time.strftime('%Y-%m-%d %H:%M:%S'),
                "update_time": item.update_time.strftime('%Y-%m-%d %H:%M:%S')
            } for item in paginated.items]
        })

    # 新增采集规则
    @app.route('/api/crawl_rules/add', methods=['POST'])
    @login_required
    @role_required('admin')
    def api_add_crawl_rule():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        try:
            headers = data.get('request_headers', '{}')
            json.loads(headers)  # 验证JSON格式
            
            rule = CrawlRule(
                site_name=data.get('site_name', '').strip(),
                site_url=data.get('site_url', '').strip(),
                title_xpath=data.get('title_xpath', '').strip(),
                content_xpath=data.get('content_xpath', '').strip(),
                request_headers=headers
            )
            db.session.add(rule)
            db.session.commit()
            return jsonify({"code": 0, "msg": "添加成功"})
        except json.JSONDecodeError:
            return jsonify({"code": 400, "msg": "Request Headers格式错误"}), 400
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 更新采集规则
    @app.route('/api/crawl_rules/update', methods=['POST'])
    @login_required
    @role_required('admin')
    def api_update_crawl_rule():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        rule_id = data.get('id')
        if not rule_id:
            return jsonify({"code": 400, "msg": "缺少规则ID"}), 400
        
        try:
            rule = CrawlRule.query.get(rule_id)
            if not rule:
                return jsonify({"code": 404, "msg": "规则不存在"}), 404
            
            headers = data.get('request_headers', rule.request_headers)
            json.loads(headers)  # 验证JSON格式
            
            rule.site_name = data.get('site_name', rule.site_name)
            rule.site_url = data.get('site_url', rule.site_url)
            rule.title_xpath = data.get('title_xpath', rule.title_xpath)
            rule.content_xpath = data.get('content_xpath', rule.content_xpath)
            rule.request_headers = headers
            
            db.session.commit()
            return jsonify({"code": 0, "msg": "更新成功"})
        except json.JSONDecodeError:
            return jsonify({"code": 400, "msg": "Request Headers格式错误"}), 400
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 删除采集规则
    @app.route('/api/crawl_rules/delete', methods=['POST'])
    @login_required
    @role_required('admin')
    def api_delete_crawl_rule():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        ids = data.get('ids', [])
        if not ids:
            return jsonify({"code": 400, "msg": "缺少要删除的ID列表"}), 400
        
        try:
            deleted_count = CrawlRule.query.filter(CrawlRule.id.in_(ids)).delete(synchronize_session=False)
            db.session.commit()
            return jsonify({"code": 0, "msg": f"成功删除 {deleted_count} 条规则"})
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # AI引擎管理页面
    @app.route('/ai_engines')
    @login_required
    @role_required('admin')
    def ai_engines():
        settings = {s.key: s.value for s in Setting.query.all()}
        return render_template('ai_engines.html', settings=settings)

    # 获取AI引擎列表
    @app.route('/api/ai_engines')
    @login_required
    @role_required('admin')
    def api_get_ai_engines():
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        
        paginated = AIEngine.query.order_by(AIEngine.create_time.desc()).paginate(
            page=page, per_page=limit, error_out=False
        )
        
        return jsonify({
            "code": 0,
            "msg": "ok",
            "count": paginated.total,
            "data": [{
                "id": item.id,
                "provider_name": item.provider_name,
                "api_url": item.api_url,
                "api_key": item.api_key,
                "model_name": item.model_name,
                "is_active": item.is_active,
                "create_time": item.create_time.strftime('%Y-%m-%d %H:%M:%S'),
                "update_time": item.update_time.strftime('%Y-%m-%d %H:%M:%S')
            } for item in paginated.items]
        })

    # 新增AI引擎
    @app.route('/api/ai_engines/add', methods=['POST'])
    @login_required
    @role_required('admin')
    def api_add_ai_engine():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        try:
            engine = AIEngine(
                provider_name=data.get('provider_name', '').strip(),
                api_url=data.get('api_url', '').strip(),
                api_key=data.get('api_key', '').strip(),
                model_name=data.get('model_name', '').strip(),
                is_active=data.get('is_active', True)
            )
            db.session.add(engine)
            db.session.commit()
            return jsonify({"code": 0, "msg": "添加成功"})
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 更新AI引擎
    @app.route('/api/ai_engines/update', methods=['POST'])
    @login_required
    @role_required('admin')
    def api_update_ai_engine():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        engine_id = data.get('id')
        if not engine_id:
            return jsonify({"code": 400, "msg": "缺少引擎ID"}), 400
        
        try:
            engine = AIEngine.query.get(engine_id)
            if not engine:
                return jsonify({"code": 404, "msg": "引擎不存在"}), 404
            
            engine.provider_name = data.get('provider_name', engine.provider_name)
            engine.api_url = data.get('api_url', engine.api_url)
            engine.api_key = data.get('api_key', engine.api_key)
            engine.model_name = data.get('model_name', engine.model_name)
            engine.is_active = data.get('is_active', engine.is_active)
            
            db.session.commit()
            return jsonify({"code": 0, "msg": "更新成功"})
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 删除AI引擎
    @app.route('/api/ai_engines/delete', methods=['POST'])
    @login_required
    @role_required('admin')
    def api_delete_ai_engine():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        ids = data.get('ids', [])
        if not ids:
            return jsonify({"code": 400, "msg": "缺少要删除的ID列表"}), 400
        
        try:
            deleted_count = AIEngine.query.filter(AIEngine.id.in_(ids)).delete(synchronize_session=False)
            db.session.commit()
            return jsonify({"code": 0, "msg": f"成功删除 {deleted_count} 个引擎"})
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500

    # 获取匹配的采集规则（根据来源URL）
    @app.route('/api/warehouse/matched_rules')
    @login_required
    def api_get_matched_rules():
        data_id = request.args.get('id')
        if not data_id:
            return jsonify({"code": 400, "msg": "缺少数据ID"}), 400
        
        news_data = NewsData.query.get(data_id)
        if not news_data:
            return jsonify({"code": 404, "msg": "数据不存在"}), 404
        
        from urllib.parse import urlparse
        parsed = urlparse(news_data.url)
        domain = f"{parsed.scheme}://{parsed.netloc}"
        
        rules = CrawlRule.query.filter(CrawlRule.site_url.like(f"%{parsed.netloc}%")).all()
        
        return jsonify({
            "code": 0,
            "data": [{
                "id": r.id,
                "site_name": r.site_name,
                "site_url": r.site_url,
                "bound": r in news_data.crawl_rules
            } for r in rules]
        })

    # 绑定采集规则
    @app.route('/api/warehouse/bind_rules', methods=['POST'])
    @login_required
    def api_bind_rules():
        data = request.get_json()
        if not data:
            return jsonify({"code": 400, "msg": "缺少请求数据"}), 400
        
        data_id = data.get('id')
        rule_ids = data.get('rule_ids', [])
        
        if not data_id:
            return jsonify({"code": 400, "msg": "缺少数据ID"}), 400
        
        try:
            news_data = NewsData.query.get(data_id)
            if not news_data:
                return jsonify({"code": 404, "msg": "数据不存在"}), 404
            
            news_data.crawl_rules = []
            for rule_id in rule_ids:
                rule = CrawlRule.query.get(rule_id)
                if rule:
                    news_data.crawl_rules.append(rule)
            
            db.session.commit()
            return jsonify({"code": 0, "msg": f"成功绑定 {len(rule_ids)} 个规则"})
        except Exception as e:
            db.session.rollback()
            return jsonify({"code": 500, "msg": str(e)}), 500
