import os
import sys
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash
from sqlalchemy import text
from datetime import timedelta

from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

db = SQLAlchemy()
migrate = Migrate()

def create_app():
    # Support normal run and PyInstaller runtime
    def _resource_path(*parts):
        base = getattr(sys, '_MEIPASS', None)
        if base:
            return os.path.join(base, *parts)
        # not frozen: resolve relative to this package (project/)
        return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), *parts)

    # Prefer bundled 'project/...' (PyInstaller --add-data) then fallback
    tpl_candidate = _resource_path('project', 'templates')
    static_candidate = _resource_path('project', 'static')
    if not os.path.isdir(tpl_candidate):
        tpl_candidate = _resource_path('templates')
    if not os.path.isdir(static_candidate):
        static_candidate = _resource_path('static')

    template_dir = tpl_candidate
    static_dir = static_candidate

    app = Flask(__name__, template_folder=template_dir, static_folder=static_dir)

    # Load config via file path to support frozen (PyInstaller) runtime
    cfg_path = _resource_path('project', 'config', 'default.py')
    if not os.path.isfile(cfg_path):
        cfg_path = _resource_path('config', 'default.py')
    if os.path.isfile(cfg_path):
        app.config.from_pyfile(cfg_path, silent=True)
    else:
        # Fallback minimal config
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.abspath(
            _resource_path('project', 'app.db')
        ).replace('\\', '/')
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Ensure secret key exists for sessions/flash
    if not app.config.get('SECRET_KEY'):
        app.config['SECRET_KEY'] = 'dev-secret-key-change-me'
    # 记住我会话有效期
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)

    db.init_app(app)
    migrate.init_app(app, db)

    with app.app_context():
        from . import routes, models
        # Create tables if not exist
        db.create_all()

        # SQLite: ensure 'role' column exists on user table (id,name,password may come from older schema)
        try:
            cols = db.session.execute(text("PRAGMA table_info(user)")).fetchall()
            has_role = any(c[1] == 'role' for c in cols)
            if not has_role:
                db.session.execute(text("ALTER TABLE user ADD COLUMN role VARCHAR(32) NOT NULL DEFAULT 'user'"))
                db.session.commit()
        except Exception:
            # best-effort; don't crash app init
            db.session.rollback()

        # Seed a default admin user for first login
        from .models import User
        if not User.query.filter_by(username='admin').first():
            user = User(
                username='admin',
                password=generate_password_hash('admin123'),  # default password
                role='admin'
            )
            db.session.add(user)
            db.session.commit()
        else:
            # Ensure the built-in 'admin' account always has admin role
            admin_user = User.query.filter_by(username='admin').first()
            if admin_user and admin_user.role != 'admin':
                admin_user.role = 'admin'
                db.session.commit()

        routes.register_routes(app)
        return app
