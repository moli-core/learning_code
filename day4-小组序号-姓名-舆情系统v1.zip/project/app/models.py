from . import db
from datetime import datetime

# 数据与采集规则的多对多关联表
news_crawl_rules = db.Table('news_crawl_rules',
    db.Column('news_id', db.Integer, db.ForeignKey('news_data.id'), primary_key=True),
    db.Column('rule_id', db.Integer, db.ForeignKey('crawl_rule.id'), primary_key=True)
)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(128), unique=True, nullable=False)
    password = db.Column(db.String(256), nullable=False)  # 存储哈希后的密码
    role = db.Column(db.String(32), nullable=False, default='user')  # user/admin

class Setting(db.Model):
    __tablename__ = 'setting'
    key = db.Column(db.String(64), primary_key=True)  # 如 app_name / logo_url
    value = db.Column(db.String(512), nullable=False, default="")

class NewsData(db.Model):
    __tablename__ = 'news_data'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    keyword = db.Column(db.String(128), nullable=False, index=True)  # 搜索关键词
    title = db.Column(db.String(512), nullable=False)  # 新闻标题
    summary = db.Column(db.Text, nullable=False, default="")  # 新闻概要
    cover = db.Column(db.String(512), nullable=True)  # 封面图片URL
    url = db.Column(db.String(512), nullable=False)  # 原始URL
    source = db.Column(db.String(128), nullable=False, default="未知来源")  # 来源
    crawl_time = db.Column(db.DateTime, nullable=False, default=datetime.now)  # 爬取时间
    page_num = db.Column(db.Integer, nullable=False, default=1)  # 页码
    unique_hash = db.Column(db.String(64), unique=True, nullable=False)  # 唯一标识，用于去重
    
    # 关联的采集规则
    crawl_rules = db.relationship('CrawlRule', secondary=news_crawl_rules, backref='news_items')
    
    def __repr__(self):
        return f'<NewsData {self.title}>'

class DeepCrawlData(db.Model):
    """深度采集数据表"""
    __tablename__ = 'deep_crawl_data'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    keyword = db.Column(db.String(128), nullable=False, index=True)  # 搜索关键词
    title = db.Column(db.String(512), nullable=False)  # 新闻标题
    summary = db.Column(db.Text, nullable=False, default="")  # 新闻概要
    full_content = db.Column(db.Text, nullable=False, default="")  # 全文内容（深度采集）
    cover = db.Column(db.String(512), nullable=True)  # 封面图片URL
    url = db.Column(db.String(512), nullable=False)  # 原始URL
    source = db.Column(db.String(128), nullable=False, default="未知来源")  # 来源
    publish_time = db.Column(db.DateTime, nullable=True)  # 发布时间
    crawl_time = db.Column(db.DateTime, nullable=False, default=datetime.now)  # 爬取时间
    author = db.Column(db.String(128), nullable=True)  # 作者
    category = db.Column(db.String(128), nullable=True)  # 分类
    tags = db.Column(db.String(512), nullable=True)  # 标签，用逗号分隔
    sentiment = db.Column(db.Integer, nullable=True)  # 情感分析：1正向，0中性，-1负向
    is_stored = db.Column(db.Boolean, nullable=False, default=False)  # 是否已存储到主表
    unique_hash = db.Column(db.String(64), unique=True, nullable=False)  # 唯一标识，用于去重
    
    def __repr__(self):
        return f'<DeepCrawlData {self.title}>'

class CrawlRule(db.Model):
    """采集规则库"""
    __tablename__ = 'crawl_rule'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    site_name = db.Column(db.String(128), nullable=False)  # 站点名称
    site_url = db.Column(db.String(512), nullable=False)  # 站点URL
    title_xpath = db.Column(db.String(512), nullable=False)  # 标题XPath
    content_xpath = db.Column(db.String(512), nullable=False)  # 详细内容XPath
    request_headers = db.Column(db.Text, nullable=False, default="{}")  # Request Headers (JSON格式)
    create_time = db.Column(db.DateTime, nullable=False, default=datetime.now)
    update_time = db.Column(db.DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)
    
    def __repr__(self):
        return f'<CrawlRule {self.site_name}>'

class AIEngine(db.Model):
    """AI引擎管理"""
    __tablename__ = 'ai_engine'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    provider_name = db.Column(db.String(128), nullable=False)  # 服务商名称
    api_url = db.Column(db.String(512), nullable=False)  # API URL
    api_key = db.Column(db.String(512), nullable=False)  # API Key
    model_name = db.Column(db.String(128), nullable=False)  # 模型名称
    is_active = db.Column(db.Boolean, nullable=False, default=True)  # 是否启用
    create_time = db.Column(db.DateTime, nullable=False, default=datetime.now)
    update_time = db.Column(db.DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)
    
    def __repr__(self):
        return f'<AIEngine {self.provider_name}>'
