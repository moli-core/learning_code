import requests
from bs4 import BeautifulSoup
import random
import time
import hashlib

def fetch_baidu_news(keyword, limit=20):
    """基础爬虫函数，获取百度新闻搜索结果"""
    # 真实请求头（需替换为自己的User-Agent和Cookie）
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Referer': 'https://www.baidu.com/',
        'Cookie': 'BDUSS=...; BIDUPSID=...; PSTM=...; BAIDUID=...; __bid=...; H_PS_PT=...; bdshare=...; BDUSS=...; Hm_lvt_...=...; Hm_lpvt_...=...'  # 需替换为真实Cookie
    }
    try:
        # 百度新闻搜索URL（添加新闻分类t=news，提高匹配度）
        url = f'https://www.baidu.com/s?wd={requests.utils.quote(keyword)}&pn=0&rn={limit}&ie=utf-8&t=news'
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        
        # 保存页面内容到本地文件以便分析
        with open('test_page.html', 'w', encoding='utf-8') as f:
            f.write(response.text)
        
        soup = BeautifulSoup(response.text, 'html.parser')
        news_items = []
        
        # 通用选择器（适配百度页面结构变化）
        for item in soup.find_all('div', class_=lambda x: x and 'result' in x and 'container' in x):
            if len(news_items) >= limit:
                break
            
            # 提取标题（支持多种h3结构）
            title_tag = item.find('h3', class_=lambda x: x and 't' in x)
            title = title_tag.text.strip() if title_tag else item.find('h3').text.strip() if item.find('h3') else ''
            
            # 提取摘要（使用更准确的c-abstract类）
            summary_tag = item.find('p', class_='c-abstract')
            summary = summary_tag.text.strip() if summary_tag else ''
            
            # 提取URL（支持a标签的href）
            url_tag = item.find('a')
            url = url_tag['href'] if url_tag else ''
            
            # 提取来源（使用更准确的c-source类）
            source_tag = item.find('span', class_='c-source')
            source = source_tag.text.strip() if source_tag else ''
            
            news_items.append({
                '标题': title,
                '概要': summary,
                '原始URL': url,
                '来源': source
            })
        
        return news_items
    except Exception as e:
        print(f"基础爬虫错误: {str(e)}")
        print(f"请求URL: {url}")
        print(f"响应状态码: {response.status_code if 'response' in locals() else '无响应'}")
        print(f"响应内容长度: {len(response.text) if 'response' in locals() else 0}")
        return []

def fetch_baidu_news_enhanced(keyword, total_limit=50, pages=3, enable_delay=True):
    """增强版爬虫函数，支持多页和反爬机制"""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Referer': 'https://www.baidu.com/',
        'Cookie': 'BDUSS=...; BIDUPSID=...; PSTM=...; BAIDUID=...'
    }
    all_items = []
    for page in range(pages):
        pn = page * 10
        url = f'https://www.baidu.com/s?wd={requests.utils.quote(keyword)}&pn={pn}&rn=10&ie=utf-8&t=news'
        try:
            response = requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            for item in soup.find_all('div', class_=lambda x: x and 'result' in x and 'container' in x):
                if len(all_items) >= total_limit:
                    break
                
                title_tag = item.find('h3', class_=lambda x: x and 't' in x)
                title = title_tag.text.strip() if title_tag else item.find('h3').text.strip() if item.find('h3') else ''
                
                summary_tag = item.find('p', class_='c-abstract')
                summary = summary_tag.text.strip() if summary_tag else ''
                
                url_tag = item.find('a')
                item_url = url_tag['href'] if url_tag and url_tag.get('href') else ''
                
                source_tag = item.find('span', class_='c-source')
                source = source_tag.text.strip() if source_tag else ''
                
                cover_tag = item.find('img')
                cover = cover_tag['src'] if cover_tag and cover_tag.get('src') else ''
                
                all_items.append({
                    'title': title,
                    'summary': summary,
                    'url': item_url,
                    'source': source,
                    'cover': cover,
                    'page': page + 1
                })
            
            if len(all_items) >= total_limit:
                break
            if enable_delay and page < pages - 1:
                time.sleep(random.uniform(1, 3))
        except Exception as e:
            print(f"增强版爬虫错误: {str(e)}")
            continue
    return all_items[:total_limit]

def fetch_article_content(url):
    """获取文章详细内容"""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Connection': 'keep-alive'
    }
    try:
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 移除脚本和样式标签
        for tag in soup(['script', 'style', 'nav', 'header', 'footer', 'aside']):
            tag.decompose()
        
        # 尝试多种常见的内容选择器
        content = None
        selectors = [
            {'name': 'article'},
            {'class_': lambda x: x and 'content' in x.lower()},
            {'class_': lambda x: x and 'article' in x.lower()},
            {'id': lambda x: x and 'content' in x.lower()},
            {'class_': lambda x: x and 'text' in x.lower()}
        ]
        
        for selector in selectors:
            element = soup.find('div', **selector) or soup.find('article', **selector)
            if element:
                content = element.get_text(separator='\n', strip=True)
                if len(content) > 100:
                    break
        
        if not content:
            # 如果没找到，获取body中的所有段落
            paragraphs = soup.find_all('p')
            content = '\n\n'.join([p.get_text(strip=True) for p in paragraphs if len(p.get_text(strip=True)) > 20])
        
        return content if content else '无法提取文章内容'
    except Exception as e:
        return f'采集失败: {str(e)}'

def fetch_with_rule(url, title_xpath, content_xpath, headers=None):
    """使用指定规则采集文章内容"""
    from lxml import etree
    
    if headers is None:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }
    
    process = []
    try:
        process.append({"step": "使用绑定规则", "status": "进行中", "detail": f"访问: {url}"})
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        
        tree = etree.HTML(response.text)
        
        # 提取标题
        title_result = tree.xpath(title_xpath)
        title = ''
        if title_result:
            title = title_result[0].text_content().strip() if hasattr(title_result[0], 'text_content') else str(title_result[0]).strip()
        
        # 提取内容
        content_result = tree.xpath(content_xpath)
        content = ''
        if content_result:
            texts = [p.text_content().strip() for p in content_result if hasattr(p, 'text_content') and len(p.text_content().strip()) > 20]
            content = '\n\n'.join(texts)
        
        if title and len(title) > 5 and content and len(content) > 100:
            process[-1]["status"] = "成功"
            process[-1]["detail"] = f"标题: {title[:30]}..., 内容: {len(content)} 字符"
            return {
                'success': True,
                'process': process,
                'title': title,
                'content': content
            }
        else:
            process[-1]["status"] = "失败"
            process[-1]["detail"] = "规则提取的内容不符合要求"
            return {
                'success': False,
                'process': process,
                'title': title,
                'content': content
            }
    except Exception as e:
        process.append({"step": "规则采集失败", "status": "失败", "detail": str(e)})
        return {
            'success': False,
            'process': process,
            'title': '',
            'content': ''
        }

def fetch_article_content_detailed(url, source=''):
    """详细采集文章内容，返回采集过程和结果"""
    from urllib.parse import urlparse
    from lxml import etree
    
    process = []
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9'
    }
    
    try:
        # 步骤1: 访问URL
        process.append({"step": "访问URL", "status": "进行中", "detail": f"正在访问: {url}"})
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        process[-1]["status"] = "成功"
        process[-1]["detail"] = f"HTTP {response.status_code}, 内容长度: {len(response.text)} 字节"
        
        # 步骤2: 解析HTML
        process.append({"step": "解析HTML", "status": "进行中", "detail": "使用BeautifulSoup解析页面"})
        soup = BeautifulSoup(response.text, 'html.parser')
        tree = etree.HTML(response.text)
        process[-1]["status"] = "成功"
        
        # 移除无用标签
        for tag in soup(['script', 'style', 'nav', 'header', 'footer', 'aside', 'iframe']):
            tag.decompose()
        
        # 步骤3: 提取标题
        process.append({"step": "提取标题", "status": "进行中", "detail": "尝试多种选择器"})
        title = None
        title_xpath = None
        
        title_selectors = [
            ('//h1[@class="title"]', 'h1.title'),
            ('//h1[contains(@class, "title")]', 'h1[class*="title"]'),
            ('//h1', 'h1'),
            ('//title', 'title'),
            ('//meta[@property="og:title"]/@content', 'meta[property="og:title"]')
        ]
        
        for xpath, desc in title_selectors:
            try:
                result = tree.xpath(xpath)
                if result:
                    if isinstance(result[0], str):
                        title = result[0].strip()
                    else:
                        title = result[0].text_content().strip()
                    if title and len(title) > 5:
                        title_xpath = xpath
                        process[-1]["detail"] = f"使用选择器: {desc}"
                        break
            except:
                continue
        
        if not title:
            title_tag = soup.find('h1') or soup.find('title')
            title = title_tag.get_text(strip=True) if title_tag else ''
            title_xpath = '//h1 | //title'
        
        if title and len(title) > 5:
            process[-1]["status"] = "成功"
            process[-1]["detail"] += f" → 标题: {title[:50]}..."
        else:
            process[-1]["status"] = "失败"
            process[-1]["detail"] = "未找到有效标题"
            return {
                'success': False,
                'process': process,
                'title': '',
                'content': ''
            }
        
        # 步骤4: 提取正文内容
        process.append({"step": "提取正文", "status": "进行中", "detail": "尝试多种内容选择器"})
        content = None
        content_xpath = None
        
        content_selectors = [
            ('//article//p', 'article p'),
            ('//div[contains(@class, "content")]//p', 'div.content p'),
            ('//div[contains(@class, "article")]//p', 'div.article p'),
            ('//div[@id="content"]//p', 'div#content p'),
            ('//div[contains(@class, "text")]//p', 'div.text p'),
            ('//p', 'p')
        ]
        
        for xpath, desc in content_selectors:
            try:
                paragraphs = tree.xpath(xpath)
                if paragraphs:
                    texts = [p.text_content().strip() for p in paragraphs if len(p.text_content().strip()) > 20]
                    if texts and len('\n\n'.join(texts)) > 100:
                        content = '\n\n'.join(texts)
                        content_xpath = xpath
                        process[-1]["detail"] = f"使用选择器: {desc}, 找到 {len(texts)} 个段落"
                        break
            except:
                continue
        
        if not content:
            paragraphs = soup.find_all('p')
            texts = [p.get_text(strip=True) for p in paragraphs if len(p.get_text(strip=True)) > 20]
            content = '\n\n'.join(texts) if texts else ''
            content_xpath = '//p'
        
        if content and len(content) > 100:
            process[-1]["status"] = "成功"
            process[-1]["detail"] += f" → 内容长度: {len(content)} 字符"
        else:
            process[-1]["status"] = "失败"
            process[-1]["detail"] = "未找到有效正文内容"
            return {
                'success': False,
                'process': process,
                'title': title,
                'content': ''
            }
        
        # 步骤5: 生成采集规则
        process.append({"step": "生成规则", "status": "成功", "detail": f"标题XPath: {title_xpath}, 内容XPath: {content_xpath}"})
        
        parsed_url = urlparse(url)
        site_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        
        return {
            'success': True,
            'process': process,
            'title': title,
            'content': content,
            'rule': {
                'site_name': source or parsed_url.netloc,
                'site_url': site_url,
                'title_xpath': title_xpath,
                'content_xpath': content_xpath,
                'headers': headers
            }
        }
        
    except requests.RequestException as e:
        process.append({"step": "错误", "status": "失败", "detail": f"网络请求失败: {str(e)}"})
        return {
            'success': False,
            'process': process,
            'title': '',
            'content': ''
        }
    except Exception as e:
        process.append({"step": "错误", "status": "失败", "detail": f"解析失败: {str(e)}"})
        return {
            'success': False,
            'process': process,
            'title': '',
            'content': ''
        }
