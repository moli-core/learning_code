if __name__ == "__main__":
    from app.main import main
    main()