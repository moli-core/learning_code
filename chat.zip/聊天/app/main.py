import tornado.web
import tornado.ioloop
import tornado.httpserver
import tornado.options
from tornado.options import define, options
import json
import os

from app.views import MainHandler, LoginHandler
from app.chat import ChatWebSocketHandler

define("port", default=8893, help="run on the given port", type=int)


class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/", MainHandler),
            (r"/login", LoginHandler),
            (r"/websocket", ChatWebSocketHandler),
        ]
        
        settings = dict(
            template_path=os.path.join(os.path.dirname(__file__), "../templates"),
            static_path=os.path.join(os.path.dirname(__file__), "../static"),
            debug=True,
        )
        
        super(Application, self).__init__(handlers, None, None, **settings)


def main():
    tornado.options.parse_command_line()
    app = Application()
    server = tornado.httpserver.HTTPServer(app)
    server.listen(options.port)
    print(f"服务器运行在端口 {options.port}")
    tornado.ioloop.IOLoop.current().start()