import tornado.web
import json
from config import WEBSOCKET_SERVERS

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        """主页处理函数"""
        # 严格检查用户是否已登录 - 只信任服务器设置的cookie
        username = self.get_cookie("username")
        
        # 确保用户名有效且不为空
        if not username or not username.strip():
            # 清理可能存在的无效cookie
            self.clear_cookie("username")
            self.redirect("/login")
            return
            
        # 验证通过，渲染聊天页面
        self.render("chat.html")

class LoginHandler(tornado.web.RequestHandler):
    def get(self):
        """登录页处理函数"""
        self.render("login.html", servers=WEBSOCKET_SERVERS)
    
    def post(self):
        """处理登录表单提交"""
        username = self.get_body_argument("username", "")
        password = self.get_body_argument("password", "")
        server = self.get_body_argument("server", "")
        
        # 简单验证
        if username and password == "123456" and server in WEBSOCKET_SERVERS:
            # 登录成功，设置cookie
            self.set_cookie("username", username, expires_days=1, httponly=False, path="/")
            self.write({
                "status": "success",
                "username": username,
                "server": server
            })
        else:
            # 登录失败
            self.write({
                "status": "error",
                "message": "用户名、密码或服务器不正确"
            })