import tornado.websocket
import json
from datetime import datetime
import aiohttp
import asyncio

class ChatWebSocketHandler(tornado.websocket.WebSocketHandler):
    # 存储所有连接的客户端
    clients = set()
    
    def open(self, *args, **kwargs):
        """当新的WebSocket连接打开时"""
        self.clients.add(self)
        print(f"新的WebSocket连接建立: {self.request.remote_ip}")
        
        # 发送欢迎消息
        welcome_msg = {
            "type": "system",
            "content": "欢迎来到小赵同学的聊天室!",
            "timestamp": datetime.now().strftime("%H:%M")
        }
        self.write_message(json.dumps(welcome_msg))
        
        # 通知所有人有新用户加入
        join_msg = {
            "type": "system",
            "content": f"用户加入了聊天室",
            "timestamp": datetime.now().strftime("%H:%M")
        }
        self.broadcast_message(join_msg)
    
    def on_message(self, message):
        """收到客户端消息时"""
        try:
            data = json.loads(message)
            msg_type = data.get("type")
            
            if msg_type == "chat":
                # 处理聊天消息
                chat_msg = {
                    "type": "chat",
                    "username": data.get("username", "匿名"),
                    "content": data.get("content", ""),
                    "timestamp": datetime.now().strftime("%H:%M")
                }
                
                # 检查是否是特殊命令
                content = chat_msg["content"]
                if content.startswith("@成小理"):
                    # 处理AI助手请求
                    asyncio.create_task(self.handle_ai_request(chat_msg))
                elif content.startswith("@电影"):
                    # 处理电影链接
                    self.handle_movie_request(chat_msg)
                elif content.startswith("@天气"):
                    # 处理天气查询
                    self.handle_weather_request(chat_msg)
                elif content.startswith("@新闻"):
                    # 处理新闻查询
                    self.handle_news_request(chat_msg)
                elif content.startswith("@音乐"):
                    # 处理音乐查询
                    self.handle_music_request(chat_msg)
                else:
                    # 广播普通消息
                    self.broadcast_message(chat_msg)
                    
        except json.JSONDecodeError:
            error_msg = {
                "type": "error",
                "content": "消息格式错误"
            }
            self.write_message(json.dumps(error_msg))
    
    def on_close(self):
        """当WebSocket连接关闭时"""
        if self in self.clients:
            self.clients.remove(self)
        print(f"WebSocket连接关闭: {self.request.remote_ip}")
        
        # 通知所有人有用户离开
        leave_msg = {
            "type": "system",
            "content": "用户离开了聊天室",
            "timestamp": datetime.now().strftime("%H:%M")
        }
        self.broadcast_message(leave_msg)
    
    def check_origin(self, origin):
        """检查跨域请求"""
        return True
    
    def broadcast_message(self, message):
        """广播消息给所有连接的客户端"""
        # 创建消息副本以避免并发修改问题
        clients_copy = self.clients.copy()
        for client in clients_copy:
            try:
                client.write_message(json.dumps(message))
            except:
                # 如果发送失败，从客户端集合中移除
                if client in self.clients:
                    self.clients.remove(client)
    
    async def handle_ai_request(self, message):
        """处理AI助手请求"""
        # 获取用户问题（去除@成小理前缀）
        user_question = message["content"][4:].strip()  # 去除"@成小理"
        
        if not user_question:
            response = {
                "type": "system",
                "content": "请输入你要咨询的问题",
                "timestamp": datetime.now().strftime("%H:%M")
            }
            self.write_message(json.dumps(response))
            return
        
        # 构建AI回复消息占位符
        ai_placeholder = {
            "type": "ai_start",
            "username": "成小理",
            "content": "",
            "timestamp": datetime.now().strftime("%H:%M")
        }
        self.write_message(json.dumps(ai_placeholder))
        
        try:
            # 调用AI服务
            api_key = "sk-qnhvpfxfxwmcfqywwjmqravexflvuneiqdumgcwgeojpilyr"
            model = "Qwen/Qwen2.5-7B-Instruct"
            api_url = "https://api.siliconflow.cn/v1/chat/completions"
            
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": model,
                "messages": [
                    {"role": "user", "content": user_question}
                ],
                "stream": True
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(api_url, headers=headers, json=payload) as resp:
                    if resp.status == 200:
                        # 逐块读取响应
                        async for data, _ in resp.content.iter_chunks():
                            if data:
                                try:
                                    # 解析SSE数据
                                    decoded_data = data.decode('utf-8')
                                    lines = decoded_data.split('\n')
                                    
                                    for line in lines:
                                        if line.startswith('data:'):
                                            json_str = line[5:].strip()  # 移除"data:"前缀
                                            if json_str == '[DONE]':
                                                # 结束标记
                                                break
                                            
                                            chunk_data = json.loads(json_str)
                                            if 'choices' in chunk_data and len(chunk_data['choices']) > 0:
                                                delta = chunk_data['choices'][0].get('delta', {})
                                                content = delta.get('content', '')
                                                
                                                if content:
                                                    # 发送AI回复片段
                                                    ai_chunk = {
                                                        "type": "ai_response",
                                                        "content": content
                                                    }
                                                    self.write_message(json.dumps(ai_chunk))
                                                    
                                except json.JSONDecodeError:
                                    # 忽略解析错误
                                    continue
                    else:
                        # 请求失败
                        error_response = {
                            "type": "system",
                            "content": f"AI服务请求失败: {resp.status}",
                            "timestamp": datetime.now().strftime("%H:%M")
                        }
                        self.write_message(json.dumps(error_response))
                        
        except Exception as e:
            # 异常处理
            error_response = {
                "type": "system",
                "content": f"AI服务异常: {str(e)}",
                "timestamp": datetime.now().strftime("%H:%M")
            }
            self.write_message(json.dumps(error_response))
    
    def handle_movie_request(self, message):
        """处理电影链接请求"""
        # 提取URL
        content = message["content"]
        parts = content.split(" ", 2)  # 分割成最多3部分
        
        if len(parts) >= 2:
            url = parts[1]  # 第二部分应该是URL
            
            # 发送电影消息
            movie_msg = {
                "type": "movie",
                "username": message["username"],
                "url": url,
                "timestamp": datetime.now().strftime("%H:%M")
            }
            self.broadcast_message(movie_msg)
        else:
            # 没有提供URL
            error_msg = {
                "type": "system",
                "content": "请提供有效的视频URL，格式: @电影 [url]",
                "timestamp": datetime.now().strftime("%H:%M")
            }
            self.write_message(json.dumps(error_msg))
    
    def handle_weather_request(self, message):
        """处理天气查询请求"""
        response = {
            "type": "system",
            "content": "天气功能正在开发中，敬请期待！",
            "timestamp": datetime.now().strftime("%H:%M")
        }
        self.write_message(json.dumps(response))
    
    def handle_news_request(self, message):
        """处理新闻查询请求"""
        response = {
            "type": "system",
            "content": "新闻功能正在开发中，敬请期待！",
            "timestamp": datetime.now().strftime("%H:%M")
        }
        self.write_message(json.dumps(response))
    
    def handle_music_request(self, message):
        """处理音乐查询请求"""
        response = {
            "type": "system",
            "content": "音乐功能正在开发中，敬请期待！",
            "timestamp": datetime.now().strftime("%H:%M")
        }
        self.write_message(json.dumps(response))