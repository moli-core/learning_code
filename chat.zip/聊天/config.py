import os

# WebSocket服务器配置
WEBSOCKET_SERVERS = [
    "ws://localhost:8893/websocket",
    "ws://127.0.0.1:8893/websocket"
]

# Flask应用配置
SECRET_KEY = os.environ.get('SECRET_KEY') or 'hard-to-guess-string'