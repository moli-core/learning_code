import time
import urllib.parse
from typing import List, Dict, Any, Optional

import requests
from bs4 import BeautifulSoup


# Minimal headers to simulate a browser and improve success rate
_DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Connection": "keep-alive",
    "Referer": "https://news.baidu.com/",
}


def _build_url(keyword: str) -> str:
    """
    Build the Baidu News search URL for the given keyword.
    """
    base = "https://www.baidu.com/s"
    # rtt=1&bsst=1&cl=2&tn=news&rsv_dl=ns_pc&word=keyword
    params = {
        "rtt": "1",
        "bsst": "1",
        "cl": "2",
        "tn": "news",
        "rsv_dl": "ns_pc",
        "word": keyword,
        # anti-cache
        "_t": str(int(time.time() * 1000)),
    }
    return f"{base}?{urllib.parse.urlencode(params, safe='')}"


def _first_text(soup: BeautifulSoup, selectors: List[str]) -> str:
    for sel in selectors:
        el = soup.select_one(sel)
        if el:
            txt = el.get_text(" ", strip=True)
            if txt:
                return txt
    return ""


def _first_attr(soup: BeautifulSoup, selectors: List[str], attrs: List[str]) -> Optional[str]:
    for sel in selectors:
        el = soup.select_one(sel)
        if el:
            for a in attrs:
                v = el.get(a)
                if v:
                    return v
    return None


def _normalize_url(u: Optional[str]) -> Optional[str]:
    if not u:
        return None
    u = u.strip()
    if not u:
        return None
    # Some images/links may be protocol-relative //...
    if u.startswith("//"):
        return "https:" + u
    return u


def fetch_baidu_news(keyword: str, limit: int = 20, timeout: int = 10) -> List[Dict[str, Any]]:
    """
    Fetch Baidu news results for a keyword.

    Returns a list of items with keys:
      - title (标题)
      - summary (概要)
      - cover (封面)
      - url (原始URL; may be Baidu redirect link)
      - source (来源)
    """
    url = _build_url(keyword)
    resp = requests.get(url, headers=_DEFAULT_HEADERS, timeout=timeout)
    resp.raise_for_status()

    # Prefer lxml if available (faster, more tolerant), otherwise fallback to stdlib parser
    try:
        soup = BeautifulSoup(resp.text, "lxml")
    except Exception:
        soup = BeautifulSoup(resp.text, "html.parser")

    # Collect candidate containers; Baidu DOM may vary, so select broadly
    containers = []
    for sel in ["div.result", "div.result-op", "div.c-container", "div.news-card", "div>div.result"]:
        containers.extend(soup.select(sel))

    results: List[Dict[str, Any]] = []
    seen_urls = set()

    for box in containers:
        # Title and URL
        title_el = None
        for sel in ["h3 a", "a.news-title", "h3 > a", "a.c-title", "a"]:
            t = box.select_one(sel)
            if t and t.get_text(strip=True):
                title_el = t
                break
        if not title_el:
            continue

        title = title_el.get_text(" ", strip=True)
        href = _normalize_url(
            _first_attr(box, ["h3 a", "a.news-title", "a.c-title", "a"], ["href", "data-landurl", "data-url"])
        )

        # Summary
        summary = _first_text(box, [".c-abstract", ".c-summary", ".content", ".news-summary", ".news-desc", "p"])

        # Source
        source = _first_text(
            box,
            [".c-color-gray", ".c-color-gray2", ".news-source", ".source", ".author", ".news-from"]
        )

        # Cover image
        cover = _normalize_url(
            _first_attr(
                box,
                ["img", ".news-img img", ".img img"],
                ["src", "data-src", "data-original", "data-thumb"]
            )
        )

        # Basic dedupe by URL + title
        key = (href or "") + "|" + title
        if key in seen_urls:
            continue
        seen_urls.add(key)

        item = {
            "title": title,       # 标题
            "summary": summary,   # 概要
            "cover": cover,       # 封面
            "url": href,          # 原始URL（可能为百度跳转链接）
            "source": source,     # 来源
        }
        results.append(item)
        if len(results) >= limit:
            break

    return results
