from . import db

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(128), unique=True, nullable=False)
    password = db.Column(db.String(256), nullable=False)  # 存储哈希后的密码
    role = db.Column(db.String(32), nullable=False, default='user')  # user/admin

class Setting(db.Model):
    __tablename__ = 'setting'
    key = db.Column(db.String(64), primary_key=True)  # 如 app_name / logo_url
    value = db.Column(db.String(512), nullable=False, default="")
