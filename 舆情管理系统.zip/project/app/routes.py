from flask import render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import check_password_hash, generate_password_hash
from . import db

def register_routes(app):
    from .models import User, Setting
    from .crawler import fetch_baidu_news
    from functools import wraps

    # 将当前用户和是否管理员注入到所有模板，避免依赖可能滞后的 session.role
    @app.context_processor
    def inject_user():
        try:
            uid = session.get('user_id')
            user = User.query.get(uid) if uid else None
            return dict(current_user=user, is_admin=bool(user and user.role == 'admin'))
        except Exception:
            return dict(current_user=None, is_admin=False)

    # 登录态守卫
    def login_required(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not session.get('user_id'):
                return redirect(url_for('login'))
            return f(*args, **kwargs)
        return decorated

    # 角色守卫
    def role_required(role):
        def deco(f):
            @wraps(f)
            def decorated(*args, **kwargs):
                if session.get('role') != role:
                    flash('权限不足', 'error')
                    return redirect(url_for('index'))
                return f(*args, **kwargs)
            return decorated
        return deco
    @app.route('/')
    def index():
        # Default page: if unauthenticated, redirect to login
        if not session.get('user_id'):
            return redirect(url_for('login'))
        settings = {s.key: s.value for s in Setting.query.all()}
        return render_template('index.html', settings=settings)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        # Load settings to render app name/logo on login page as well
        settings = {s.key: s.value for s in Setting.query.all()}
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            remember = request.form.get('remember') == 'on'
            user = User.query.filter_by(username=username).first()
            if user and check_password_hash(user.password, password):
                # Harden: ensure built-in admin always has admin role
                if user.username == 'admin' and user.role != 'admin':
                    user.role = 'admin'
                    db.session.commit()
                session['user_id'] = user.id
                session['username'] = user.username
                session['role'] = user.role
                session.permanent = remember
                flash('登录成功', 'success')
                return redirect(url_for('index'))
            else:
                flash('用户名或密码错误', 'error')
                return render_template('login.html', username=username, settings=settings)
        return render_template('login.html', settings=settings)

    @app.route('/logout')
    @login_required
    def logout():
        session.clear()
        flash('已退出登录', 'success')
        return redirect(url_for('login'))

    @app.route('/dashboard')
    @login_required
    def dashboard():
        settings = {s.key: s.value for s in Setting.query.all()}
        return render_template('index.html', settings=settings)

    # 舆情采集页面
    @app.route('/crawl')
    @login_required
    def crawl_page():
        settings = {s.key: s.value for s in Setting.query.all()}
        return render_template('crawl.html', settings=settings)

    # 舆情采集接口：?q=关键词&limit=20
    @app.route('/api/crawl')
    @login_required
    def api_crawl():
        q = (request.args.get('q') or '').strip()
        try:
            limit = int(request.args.get('limit') or 20)
        except Exception:
            limit = 20
        if not q:
            return jsonify({"code": 400, "msg": "missing param q", "data": []}), 400
        try:
            items = fetch_baidu_news(q, limit=limit)
            data = [{
                "标题": it.get("title") or "",
                "概要": it.get("summary") or "",
                "封面": it.get("cover"),
                "原始URL": it.get("url"),
                "来源": it.get("source") or ""
            } for it in items]
            return jsonify({"code": 0, "msg": "ok", "count": len(data), "data": data})
        except Exception as e:
            return jsonify({"code": 500, "msg": str(e), "data": []}), 500

    @app.route('/admin')
    @login_required
    @role_required('admin')
    def admin():
        users = User.query.all()
        settings = {s.key: s.value for s in Setting.query.all()}
        return render_template('admin.html', users=users, settings=settings)

    @app.route('/admin/users/add', methods=['POST'])
    @login_required
    @role_required('admin')
    def admin_users_add():
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        role = request.form.get('role', 'user')
        if not username or not password:
            flash('用户名和密码不能为空', 'error')
            return redirect(url_for('admin'))
        if User.query.filter_by(username=username).first():
            flash('用户名已存在', 'error')
            return redirect(url_for('admin'))
        u = User(username=username, password=generate_password_hash(password), role=role)
        db.session.add(u)
        db.session.commit()
        flash('用户已创建', 'success')
        return redirect(url_for('admin'))

    @app.route('/admin/users/delete/<int:uid>', methods=['POST'])
    @login_required
    @role_required('admin')
    def admin_users_delete(uid):
        u = User.query.get_or_404(uid)
        if u.username == 'admin':
            flash('内置管理员不可删除', 'error')
            return redirect(url_for('admin'))
        db.session.delete(u)
        db.session.commit()
        flash('已删除', 'success')
        return redirect(url_for('admin'))

    @app.route('/admin/users/reset/<int:uid>', methods=['POST'])
    @login_required
    @role_required('admin')
    def admin_users_reset(uid):
        u = User.query.get_or_404(uid)
        u.password = generate_password_hash('123456')
        db.session.commit()
        flash('密码已重置为 123456', 'success')
        return redirect(url_for('admin'))

    @app.route('/admin/settings', methods=['POST'])
    @login_required
    @role_required('admin')
    def admin_settings():
        app_name = request.form.get('app_name', '').strip()
        logo_url = request.form.get('logo_url', '').strip()
        for k, v in [('app_name', app_name), ('logo_url', logo_url)]:
            s = Setting.query.get(k)
            if s:
                s.value = v
            else:
                db.session.add(Setting(key=k, value=v))
        db.session.commit()
        flash('设置已保存', 'success')
        return redirect(url_for('admin'))
