import os
import sys

def _db_path() -> str:
    """
    Prefer a writable, persistent DB path:
    - If frozen to an exe (PyInstaller), place app.db next to the executable.
    - Otherwise, place app.db in the project folder (one level up from this file).
    """
    if getattr(sys, "frozen", False) and hasattr(sys, "executable"):
        base = os.path.dirname(sys.executable)
    else:
        # project/config/default.py -> project/
        base = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    return os.path.abspath(os.path.join(base, "app.db"))

SQLALCHEMY_DATABASE_URI = "sqlite:///" + _db_path().replace("\\", "/")
SQLALCHEMY_TRACK_MODIFICATIONS = False
